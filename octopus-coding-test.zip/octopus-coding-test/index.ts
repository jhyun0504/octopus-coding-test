import findReleasesToKeep from "./findReleasesToKeep"
import deployments from "./sample/Deployments.json"
import releases from "./sample/Releases.json"

const latestReleases = findReleasesToKeep(deployments, releases)

const latestTwoReleases = findReleasesToKeep(deployments, releases, 2)

console.log(`
Latest Releases to keep: ${latestReleases}

========================================

Latest Two Releases to keep: ${latestTwoReleases}
`)
