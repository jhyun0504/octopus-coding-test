import { DateTime } from "luxon"

interface Deployment {
  Id: string;
  ReleaseId: string;
  EnvironmentId: string;
  DeployedAt: string;
}

interface Release {
  Id: string;
  ProjectId: string;
}

interface ReleaseDeploymentDetails extends Deployment {
  ProjectId: string;
}

export const mapDeploymentWithRelease = (deployment: Deployment, release: Release): ReleaseDeploymentDetails => ({
  ...deployment,
  ReleaseId: release!.Id,
  ProjectId: release!.ProjectId,
})

export const sortObjByIsoDate = (arrayOfObj: any[], key: string) => {
  return arrayOfObj.sort((a, b) => {
    return DateTime.fromISO(b[key])
      .diff(DateTime.fromISO(a[key]), "seconds")
      .seconds
  })
}

export default (deployments: Deployment[], releases: Release[], numberOfReleasesToKeep: number = 1): string[] => {
  // map releases to correct deployments
  const deploymentsMappedWithReleases = deployments.map(deployment => {
    // assume there always is a release for a deployment
    const release = releases.find(release => release.Id === deployment.ReleaseId)
  
    return mapDeploymentWithRelease(deployment, release!)
  })

  
  // map releases by project environment
  const mappedByProjectEnv = deploymentsMappedWithReleases.reduce((acc, cur) => {
    const projectEnv = cur.ProjectId + "-" + cur.EnvironmentId
    
    if (acc[projectEnv]) {
      acc[projectEnv].push(cur)
    } else {
      acc[projectEnv] = [cur]
    }
  
    return acc
  }, {} as {
    [projectEnv: string]: typeof deploymentsMappedWithReleases
  })
  
  const releaseIds: string[] = []
  
  Object.keys(mappedByProjectEnv).forEach(projectEnv => {
    // all releases in each of project environment groups are sorted by date
    mappedByProjectEnv[projectEnv] = sortObjByIsoDate(mappedByProjectEnv[projectEnv], "DeployedAt")
    
    // only take the first x number of most recently deployed releases
    const releasesToKeep = mappedByProjectEnv[projectEnv].slice(0, numberOfReleasesToKeep)

    // add release IDs which isn't already specified
    releasesToKeep.forEach(release => {
      if (!releaseIds.includes(release.ReleaseId)) {
        releaseIds.push(release.ReleaseId)
      }
    })
  })

  // sort the releaseIds purely for better readability
  return releaseIds.sort()
}