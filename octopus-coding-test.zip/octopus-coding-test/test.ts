import findReleasesToKeep, { sortObjByIsoDate, mapDeploymentWithRelease } from './findReleasesToKeep';
import deployments from "./sample/Deployments.json"
import releases from "./sample/Releases.json"

test("Object sorting by date (descending order)", () => {
  expect(sortObjByIsoDate([
    {
      "Id": "Deployment-1",
      "DeployedAt": "2000-01-01T10:00:00"
    },
    {
      "Id": "Deployment-2",
      "DeployedAt": "2000-01-02T10:00:00"
    },
    {
      "Id": "Deployment-3",
      "DeployedAt": "2000-01-02T11:00:00"
    }
  ], "DeployedAt")[0].Id).toBe("Deployment-3")
})

test("Deployment and Release mapping", () => {
  expect(JSON.stringify(mapDeploymentWithRelease(
    {
      "Id": "Deployment-1",
      "ReleaseId": "Release-1",
      "EnvironmentId": "Environment-1",
      "DeployedAt": "2000-01-01T10:00:00"
    },
    {
      "Id": "Release-1",
      "ProjectId": "Project-1"
    }
  ))).toBe(JSON.stringify({
    "Id": "Deployment-1",
    "ReleaseId": "Release-1",
    "EnvironmentId": "Environment-1",
    "DeployedAt": "2000-01-01T10:00:00",
    "ProjectId": "Project-1"
  }))
})

test("Find latest releases", () => {
  expect(JSON.stringify(findReleasesToKeep(deployments, releases))).toBe(JSON.stringify([
    'Release-1',
    'Release-2',
    'Release-6',
    'Release-8'
  ]))
})

test("Find latest two releases", () => {
  expect(JSON.stringify(findReleasesToKeep(deployments, releases, 2))).toBe(JSON.stringify([
    'Release-1',
    'Release-2',
    'Release-6',
    'Release-7',
    'Release-8'
  ]))
})